package scan.door.exitdetector

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import com.google.mlkit.common.model.LocalModel
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.DetectedObject
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.custom.CustomObjectDetectorOptions
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var cameraExecutor: ExecutorService
    private lateinit var objectDetector: com.google.mlkit.vision.objects.ObjectDetector
    private lateinit var overlayView: OverlayView
    private var cameraProvider: ProcessCameraProvider? = null

    private lateinit var textToSpeech: TextToSpeech
    private var isCurrentlySpeaking = false
    private var guidanceCooldownState: GuidanceCooldown = GuidanceCooldown()

    private var processedFrameCounter = 0

    companion object {
        private const val TAG = "DoorNavigation"
        private const val CAMERA_PERMISSION_REQUEST = 1001
        private const val MIN_CONFIDENCE_THRESHOLD = 0.5f
        private const val FRAME_SKIP_INTERVAL = 2
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        overlayView = findViewById(R.id.overlayView)
        initializeOverlayPaints()

        textToSpeech = TextToSpeech(this, this)
        textToSpeech.setOnUtteranceProgressListener(ttsProgressListener)

        if (checkCameraPermission()) {
            initializeDetectorAndStartCamera()
        } else {
            requestCameraPermission()
        }

        cameraExecutor = Executors.newSingleThreadExecutor()
    }

    private fun initializeOverlayPaints() {
        val boxPaint = Paint().apply {
            color = Color.GREEN
            style = Paint.Style.STROKE
            strokeWidth = 4f
            isAntiAlias = true
        }
        val textPaint = Paint().apply {
            color = Color.WHITE
            textSize = 36f
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val backgroundPaint = Paint().apply {
            color = "#CC000000".toColorInt()
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        overlayView.setPaints(boxPaint, textPaint, backgroundPaint)
    }

    private fun checkCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun requestCameraPermission() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == CAMERA_PERMISSION_REQUEST && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            initializeDetectorAndStartCamera()
        } else {
            Toast.makeText(this, "Camera permission denied", Toast.LENGTH_LONG).show()
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    private fun initializeDetectorAndStartCamera() {
        setupCustomObjectDetector()
        startCameraCaptureSession()
    }

    private fun setupCustomObjectDetector() {
        try {
            val localModel = LocalModel.Builder()
                .setAssetFilePath("object_detection.tflite")
                .build()

            val options = CustomObjectDetectorOptions.Builder(localModel)
                .setDetectorMode(CustomObjectDetectorOptions.SINGLE_IMAGE_MODE)
                .enableMultipleObjects()
                .enableClassification()
                .setClassificationConfidenceThreshold(0.7f)
                .setMaxPerObjectLabelCount(5)
                .build()

            objectDetector = ObjectDetection.getClient(options)

        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize object detector", e)
            Toast.makeText(this, "Object detector initialization error", Toast.LENGTH_LONG).show()
        }
    }

    @SuppressLint("UnsafeOptInUsageError")
    private fun startCameraCaptureSession() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            try {
                cameraProvider = cameraProviderFuture.get()
                bindCameraUseCasesToLifecycle()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get camera provider", e)
                Toast.makeText(this, "Camera initialization failed", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @SuppressLint("UnsafeOptInUsageError")
    private fun bindCameraUseCasesToLifecycle() {
        cameraProvider?.unbindAll()

        val preview = Preview.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            .build()

        val imageAnalysis = ImageAnalysis.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
            .also { analysis ->
                analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    processedFrameCounter++
                    if (processedFrameCounter > FRAME_SKIP_INTERVAL && !isCurrentlySpeaking) {
                        processedFrameCounter = 0
                        analyzeCameraFrame(imageProxy)
                    } else {
                        imageProxy.close()
                    }
                }
            }

        val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
        val previewView = findViewById<androidx.camera.view.PreviewView>(R.id.previewView)
        preview.setSurfaceProvider(previewView.surfaceProvider)

        cameraProvider?.bindToLifecycle(this, cameraSelector, preview, imageAnalysis)
    }

    @SuppressLint("UnsafeOptInUsageError")
    private fun analyzeCameraFrame(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        objectDetector.process(inputImage)
            .addOnSuccessListener { detectedObjects ->
                handleDetectedObjects(detectedObjects, imageProxy.width, imageProxy.height)
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Object detection failed", e)
            }
            .addOnCompleteListener {
                imageProxy.close()
            }
    }

    private fun handleDetectedObjects(detectedObjects: List<DetectedObject>, imageWidth: Int, imageHeight: Int) {
        val detectedDoors = detectedObjects.filter { it.containsLabel("door", 0.7f) }
        val detectedObstacles = detectedObjects.filter { it.isObstacleButNotDoor(detectedDoors, imageHeight) }

        runOnUiThread {
            overlayView.setDetectedObjects(detectedObjects, imageWidth, imageHeight)
            overlayView.invalidate()
            generateNavigationGuidance(detectedDoors, detectedObstacles)
            overlayView.postDelayed({ overlayView.invalidate() }, 1000)
        }
    }

    private fun DetectedObject.containsLabel(labelText: String, minConfidence: Float): Boolean =
        labels.any { it.text.equals(labelText, ignoreCase = true) && it.confidence >= minConfidence }

    private fun DetectedObject.isObstacleButNotDoor(doors: List<DetectedObject>, imageHeight: Int): Boolean {
        if (doors.isEmpty()) return false

        val door = doors.first()
        val verticalPathLimit = imageHeight * 0.6f
        val boxCurrent = boundingBox
        val boxDoor = door.boundingBox

        return labels.any { !it.text.equals("door", ignoreCase = true) && it.confidence >= MIN_CONFIDENCE_THRESHOLD } &&
                boxCurrent.bottom > verticalPathLimit &&
                boxCurrent.top < boxDoor.bottom &&
                doBoxesHorizontallyOverlap(boxCurrent, boxDoor)
    }

    private fun doBoxesHorizontallyOverlap(boxA: Rect, boxB: Rect): Boolean =
        boxA.right > boxB.left && boxA.left < boxB.right

    private fun generateNavigationGuidance(doors: List<DetectedObject>, obstacles: List<DetectedObject>) {
        if (doors.isEmpty()) {
            speakGuidance("Scanning for doors. Please move slowly.")
            return
        }

        val door = doors.first()
        val doorLabel = door.labels.firstOrNull()?.text ?: "door"
        val doorConfidencePercent = ((door.labels.firstOrNull()?.confidence ?: 0f) * 100).toInt()

        if (obstacles.isEmpty()) {
            speakGuidance("Walk straight. $doorLabel is ahead with $doorConfidencePercent% confidence.")
            return
        }

        val obstacle = obstacles.first()
        val obstacleLabel = obstacle.labels.firstOrNull()?.text ?: "object"
        val obstacleConfidencePercent = ((obstacle.labels.firstOrNull()?.confidence ?: 0f) * 100).toInt()

        val doorCenterX = door.boundingBox.centerX()
        val obstacleCenterX = obstacle.boundingBox.centerX()

        val guidanceMessage = if (obstacleCenterX < doorCenterX) {
            "Caution: $obstacleLabel detected on your left with $obstacleConfidencePercent% confidence. Move right to avoid and reach the $doorLabel."
        } else {
            "Caution: $obstacleLabel detected on your right with $obstacleConfidencePercent% confidence. Move left to avoid and reach the $doorLabel."
        }

        speakGuidance(guidanceMessage)
    }

    private fun speakGuidance(message: String) {
        val currentTime = System.currentTimeMillis()
        if (currentTime - guidanceCooldownState.lastSpoken > guidanceCooldownState.cooldownMillis || message != guidanceCooldownState.lastMessage) {
            if (!isCurrentlySpeaking) {
                guidanceCooldownState.update(message, currentTime)
                textToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null, "GUIDANCE_UTTERANCE")
                Log.d(TAG, "Speaking guidance message: $message")
            }
        }
    }

    private val ttsProgressListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            isCurrentlySpeaking = true
        }

        override fun onDone(utteranceId: String?) {
            isCurrentlySpeaking = false
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            isCurrentlySpeaking = false
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech.language = Locale.getDefault()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        cameraProvider?.unbindAll()
        textToSpeech.stop()
        textToSpeech.shutdown()
    }

    private class GuidanceCooldown(
        var lastMessage: String = "",
        var lastSpoken: Long = 0L,
        val cooldownMillis: Long = 20000L
    ) {
        fun update(message: String, timestamp: Long) {
            lastMessage = message
            lastSpoken = timestamp
        }
    }
}

class OverlayView(context: android.content.Context, attrs: android.util.AttributeSet?) : View(context, attrs) {

    private var detectedObjects: List<DetectedObject> = emptyList()
    private lateinit var boxPaint: Paint
    private lateinit var labelTextPaint: Paint
    private lateinit var labelBackgroundPaint: Paint
    private var imageWidth = 1
    private var imageHeight = 1

    private val reusableRectF = RectF() // pre-allocated for drawing reuse

    fun setPaints(boxPaint: Paint, labelTextPaint: Paint, labelBackgroundPaint: Paint) {
        this.boxPaint = boxPaint
        this.labelTextPaint = labelTextPaint
        this.labelBackgroundPaint = labelBackgroundPaint
    }

    fun setDetectedObjects(detectedObjects: List<DetectedObject>, width: Int, height: Int) {
        this.detectedObjects = detectedObjects
        this.imageWidth = width
        this.imageHeight = height
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (imageWidth == 0 || imageHeight == 0) return

        val scaleX = width.toFloat() / imageWidth
        val scaleY = height.toFloat() / imageHeight

        for (obj in detectedObjects) {
            val label = obj.labels.firstOrNull() ?: continue

            reusableRectF.set(
                obj.boundingBox.left * scaleX,
                obj.boundingBox.top * scaleY,
                obj.boundingBox.right * scaleX,
                obj.boundingBox.bottom * scaleY
            )

            canvas.drawRect(reusableRectF, boxPaint)

            val labelText = "${label.text} ${(label.confidence * 100).toInt()}%"
            val textWidth = labelTextPaint.measureText(labelText)
            val textHeight = labelTextPaint.textSize

            val textX = reusableRectF.left
            val textY = reusableRectF.top - 5f

            canvas.drawRect(
                textX - 5f,
                textY - textHeight - 5f,
                textX + textWidth + 5f,
                textY + 5f,
                labelBackgroundPaint
            )

            canvas.drawText(labelText, textX, textY, labelTextPaint)
        }
    }
}
